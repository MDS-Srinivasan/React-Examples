import React from 'react';

const ImageList = props => {
  console.log(props.images);

  return <div>ImageList</div>;
};

export default ImageList;
