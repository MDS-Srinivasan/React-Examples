import React from 'react';

class App extends React.Component {
  render() {
    return <div className="ui container">App</div>;
  }
}

export default App;
