import React from 'react';

const App = () => {
  return <div className="ui container">App</div>;
};

export default App;
