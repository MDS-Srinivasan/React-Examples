import React from 'react';

const Dropdown = () => {
  return <h1>Dropdown</h1>;
};

export default Dropdown;
