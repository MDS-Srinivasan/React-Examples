import React from 'react';
import SearchBar from './SearchBar';

const App = () => {
  return (
    <div>
      <SearchBar />
    </div>
  );
};

export default App;
