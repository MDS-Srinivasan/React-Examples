import React from 'react';
import Modal from '../Modal';

const StreamDelete = () => {
  return (
    <div>
      StreamDelete
      <Modal />
    </div>
  );
};

export default StreamDelete;
